# gera_sipacc_dataset.py
import json
import random
import uuid
from datetime import datetime, timedelta
from bson import ObjectId

# ---------- utilitários ----------
def oid_str():
    """Gera ObjectId string (24 hex)."""
    return str(ObjectId())

def ext_oid(oid=None):
    """Extended JSON objectId wrapper."""
    return {"$oid": oid or oid_str()}

def ext_date(dt=None):
    """Extended JSON date wrapper with ISO format (Z)."""
    if dt is None:
        dt = random_date()
    return {"$date": dt}

def random_date(days_back=1865):
    """ISO date string between now - days_back and now."""
    start = datetime.utcnow() - timedelta(days=days_back)
    end = datetime.utcnow()
    dt = start + (end - start) * random.random()
    return dt.replace(microsecond=0).isoformat() + "Z"

# ---------- pools de dados para variação ----------
FIRST = ["Ana","João","Mariana","Lucas","Carla","Rafael","Larissa","Tiago","Juliana",
         "Felipe","Amanda","Vinícius","Natália","Gabriel","Sabrina","Gustavo","Letícia",
         "Diego","Camila","Enzo","Bianca","Henrique","Isabela","Murilo","Bruna","Kevin"]
LAST = ["Silva","Souza","Almeida","Ribeiro","Pereira","Gomes","Rodrigues","Costa","Fernandes",
        "Melo","Oliveira","Sales","Carvalho","Duarte","Teixeira","Novaes","Martins","Barros"]
CITIES = ["São Paulo","Rio de Janeiro","Brasília","Curitiba","Salvador","Fortaleza","Manaus",
          "Belém","Porto Alegre","Recife","Florianópolis","Campinas","Goiânia","Belo Horizonte"]
STATES = ["SP","RJ","DF","PR","BA","CE","AM","PA","RS","SC","MG"]
CARGOS = ["Delegado","Investigador","Agente Federal","Perito","Analista Forense","Escrivão","Inspetor","Especialista Cibernético"]
TIPOS_INVEST = ["delegacia","policia_federal","pericia","outros"]
TIPOS_JUD = ["vara_criminal","tribunal","promotoria"]
TIPOS_CRIME = ["fraude_online", "phishing", "roubo_de_conta", "extorsao", "golpe_financeiro"]
PLATAFORMAS = ["Instagram","Facebook","WhatsApp","Telegram","E-mail","TikTok","LinkedIn","Web"]
PERFIS_TIPO = ["pessoal","comercial","fraudulenta"]
PERFIS_STATUS = ["ativa","inativa","banida"]
DOC_TIPOS = ["laudo","sentenca","despacho","mandado"]

# ---------- geradores ----------
def gen_nome():
    return f"{random.choice(FIRST)} {random.choice(LAST)}"

def gen_telefone():
    ddd = random.randint(11,99)
    return f"+55 ({ddd}) {random.randint(2000,9999)}-{random.randint(1000,9999)}"

def gen_cpf():
    return "".join(str(random.randint(0,9)) for _ in range(11))

def gen_registro():
    pref = random.choice(["AG","PR","DL","PF","MT","RV","UX","LA"])
    suf = ''.join(random.choices("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", k=6))
    return f"{pref}{suf}"

# ---------- geração de coleções (com controle de ids) ----------
def gerar_instituicoes_investigativas(n=30):
    out=[]
    for _ in range(n):
        out.append({
            "_id": ext_oid(),
            "nome": f"Delegacia {gen_nome()}",
            "tipo": random.choice(TIPOS_INVEST),
            "cidade": random.choice(CITIES),
            "contato": gen_telefone(),
            "agentes": []  # será preenchido depois com o $oid dos agentes
        })
    return out

def gerar_instituicoes_judiciais(n=12):
    out=[]
    for _ in range(n):
        out.append({
            "_id": ext_oid(),
            "nome": f"Vara {gen_nome()}",
            "tipo": random.choice(TIPOS_JUD),
            "jurisdicao": random.choice(CITIES),
            "contato": gen_telefone(),
            "autoridades_judiciais": []
        })
    return out

def gerar_agentes(n, instituicoes):
    out=[]
    inst_oids = [doc["_id"]["$oid"] for doc in instituicoes]
    for _ in range(n):
        inst = random.choice(inst_oids)
        doc = {
            "_id": ext_oid(),
            "nome": gen_nome(),
            "cargo": random.choice(CARGOS),
            "registro": gen_registro(),
            "contato": gen_telefone(),
            "instituicao_id": ext_oid(inst)
        }
        out.append(doc)
    # update instituicoes.agentes lists
    mapping = {}
    for a in out:
        iid = a["instituicao_id"]["$oid"]
        mapping.setdefault(iid, []).append(a["_id"]["$oid"])
    for inst in instituicoes:
        iid = inst["_id"]["$oid"]
        inst["agentes"] = [ext_oid(x) for x in mapping.get(iid,[])]
    return out

def gerar_instituicoes_judiciais_e_autoridades(n_inst=8, n_auth=40):
    insts = gerar_instituicoes_judiciais(n_inst)
    auths=[]
    inst_oids=[i["_id"]["$oid"] for i in insts]
    for _ in range(n_auth):
        inst_oid = random.choice(inst_oids)
        a = {
            "_id": ext_oid(),
            "nome": gen_nome(),
            "cargo": random.choice(["juiz","promotor","procurador"]),
            "contato": gen_telefone(),
            "instituicao_judicial_id": ext_oid(inst_oid)
        }
        auths.append(a)
    # fill authorities arrays
    map_auth={}
    for a in auths:
        iid = a["instituicao_judicial_id"]["$oid"]
        map_auth.setdefault(iid, []).append(a["_id"]["$oid"])
    for inst in insts:
        iid = inst["_id"]["$oid"]
        inst["autoridades_judiciais"] = [ext_oid(x) for x in map_auth.get(iid,[])]
    return insts, auths

def gerar_perfis_digitais(n=200, ocorrencias_oids=None):
    out=[]
    for _ in range(n):
        occs = []
        if ocorrencias_oids:
            occs = [ext_oid(random.choice(ocorrencias_oids)) for _ in range(random.randint(0,2))]
        doc = {
            "_id": ext_oid(),
            "plataforma": random.choice(PLATAFORMAS),
            "tipo_conta": random.choice(PERFIS_TIPO),
            "status": random.choice(PERFIS_STATUS),
            "usuario_id": None,   # users collection not modeled here; can be filled later
            "ocorrencias": occs
        }
        out.append(doc)
    return out

def gerar_denuncias(n=1000):
    out=[]
    for _ in range(n):
        doc = {
            "_id": ext_oid(),
            "descricao": f"Denúncia recebida: relato de {random.choice(['fraude','phishing','roubo de conta','extorsão'])} com indícios digitais.",
            "data": ext_date(),
            "tipo_crime": random.choice(TIPOS_CRIME),
            "plataforma": random.choice(PLATAFORMAS),
            "anexo": None,
            "ocorrencia_id": None
        }
        out.append(doc)
    return out

def gerar_ocorrencias(
        n=600,
        denuncias=None,
        instituicoes_inv=None,
        agentes=None,
        perfis=None,
        instituicoes_jud=None,
        docs_proc=None
    ):
    out = []

    # listas de ids para sorteio
    denuncias_oids = [d["_id"]["$oid"] for d in denuncias] if denuncias else []
    inst_inv_oids = [d["_id"]["$oid"] for d in instituicoes_inv] if instituicoes_inv else []
    agentes_oids = [a["_id"]["$oid"] for a in agentes] if agentes else []
    perf_oids = [p["_id"]["$oid"] for p in perfis] if perfis else []
    inst_jud_oids = [j["_id"]["$oid"] for j in instituicoes_jud] if instituicoes_jud else []
    proc_oids = [p["_id"]["$oid"] for p in docs_proc] if docs_proc else []

    # ENUM OFICIAL do JSON Schema da coleção OCORRENCIAS
    TIPOS_CRIME_OCORRENCIAS = [
        "phishing",
        "fraude_financeira",
        "roubo_de_conta",
        "extorsao",
        "invasao_sistema",
        "outros"
    ]

    for i in range(n):

        # ---------- campos relacionados a outras coleções ----------
        den = random.choice(denuncias_oids) if denuncias_oids else None

        # obrigatoriamente presente (schema exige)
        inst_inv = random.choice(inst_inv_oids) if inst_inv_oids else None
        # se por algum motivo a lista estiver vazia, cria um id para não invalidar o schema
        if inst_inv is None:
            inst_inv = oid_str()

        # minItems = 1 para agentes_responsaveis
        if agentes_oids:
            ag_count = random.randint(1, 3)
            ags = random.sample(agentes_oids, k=min(ag_count, len(agentes_oids)))
        else:
            # fallback obrigatório
            ags = [oid_str()]

        contas_digitais = []
        if perf_oids:
            contas_digitais = random.sample(
                perf_oids,
                k=min(random.randint(0, 2), len(perf_oids))
            )

        proc = None
        if proc_oids and random.random() < 0.4:
            proc = random.choice(proc_oids)

        inst_jud = None
        if inst_jud_oids and random.random() < 0.5:
            inst_jud = random.choice(inst_jud_oids)

        # ---------- documento final ----------
        doc = {
            "_id": ext_oid(),
            "tipo_crime": random.choice(TIPOS_CRIME_OCORRENCIAS),
            "data": ext_date(),
            "localizacao": random.choice(CITIES),

            "descricao": (
                f"Ocorrência #{i + 1}: "
                f"{random.choice(['acesso não autorizado','envio de phishing','transferência irregular','vazamento de dados','chantagem'])}."
            ),

            "status_investigacao": random.choice([
                "aberta", "em_andamento", "concluida", "arquivada"
            ]),

            # RELACIONAMENTOS
            "denuncia_id": ext_oid(den) if den else None,
            "instituicao_investigativa_id": ext_oid(inst_inv),
            "agentes_responsaveis": [ext_oid(a) for a in ags],

            "instituicao_judicial_id": ext_oid(inst_jud) if inst_jud else None,
            "processo_judicial_id": ext_oid(proc) if proc else None,

            # LISTAS OBRIGATÓRIAS
            "vitimas": [
                {
                    "nome": gen_nome(),
                    "cpf": gen_cpf(),
                    "contato": gen_telefone(),
                    "idade": random.randint(18, 80),
                    "sexo": random.choice(["M", "F", "Outro"])
                }
            ],

            "suspeitos": [
                {
                    "nome": random.choice([
                        "Desconhecido",
                        "Autor desconhecido",
                        "Suspeito X"
                    ]),
                    "cpf": None,
                    "apelido": None,
                    "contato": None,
                    "sexo": None
                }
            ],

            "dispositivos": [
                {
                    "tipo": random.choice(["celular", "computador", "tablet", "outro"]),
                    "sist_operacional": random.choice([
                        "Android 14", "iOS 17", "Windows 11", "Linux"
                    ]),
                    "endereco_mac": ":".join(
                        f"{random.randint(0, 255):02X}" for _ in range(6)
                    )
                }
                for _ in range(random.randint(0, 2))
            ],

            "evidencias": [
                {
                    "tipo": random.choice(["imagem", "audio", "video", "email", "log", "mensagem"]),
                    "descricao": "Evidência coletada do dispositivo/plataforma.",
                    "data_coleta": ext_date(),
                    "anexo": None,
                    "agente_id": ext_oid(random.choice(agentes_oids)) if agentes_oids else None
                }
                for _ in range(random.randint(1, 3))
            ],

            "contas_digitais": [ext_oid(c) for c in contas_digitais]
        }

        out.append(doc)

    return out


def gerar_documentos_processuais(n=400, autoridades=None, instituicoes_jud=None, ocorrencias=None):
    out=[]
    auth_oids = [a["_id"]["$oid"] for a in autoridades] if autoridades else []
    inst_j_oids = [i["_id"]["$oid"] for i in instituicoes_jud] if instituicoes_jud else []
    occ_oids = [o["_id"]["$oid"] for o in ocorrencias] if ocorrencias else []

    for _ in range(n):
        autor = random.choice(auth_oids) if auth_oids else None
        instj = random.choice(inst_j_oids) if inst_j_oids else None
        occ = random.choice(occ_oids) if occ_oids and random.random() < 0.6 else None
        doc = {
            "_id": ext_oid(),
            "tipo": random.choice(DOC_TIPOS),
            "data": ext_date(),
            "descricao": "Documento processual gerado no fluxo investigativo.",
            "arquivo": None,
            "autor_id": ext_oid(autor) if autor else None,
            "instituicao_judicial_id": ext_oid(instj) if instj else None,
            "ocorrencia_id": ext_oid(occ) if occ else None
        }
        out.append(doc)
    return out

# ---------- função util para salvar ----------
def salvar_json(nome, docs):
    with open(f"{nome}.json","w",encoding="utf-8") as f:
        json.dump(docs,f,ensure_ascii=False,indent=2)
    print(f"Gerado: {nome}.json ({len(docs)} documentos)")

# ---------- execução sequencial garantindo referências ----------
def main():
    # ajuste volumes conforme necessidade
    n_invest = 50
    n_jud = 40
    n_agents = 1000
    n_denuncias = 7000
    n_perfis = 6000
    n_doc_proc = 8000
    n_ocorrencias = 10000

    print("Gerando instituições investigativas...")
    inst_inv = gerar_instituicoes_investigativas(n_invest)
    salvar_json("instituicoes_investigativas", inst_inv)

    print("Gerando agentes...")
    agentes = gerar_agentes(n_agents, inst_inv)
    salvar_json("agentes", agentes)

    print("Gerando instituições judiciais e autoridades...")
    inst_jud, autoridades = gerar_instituicoes_judiciais_e_autoridades(n_inst=n_jud, n_auth=80)
    salvar_json("instituicoes_judiciais", inst_jud)
    salvar_json("autoridades_judiciais", autoridades)

    print("Gerando documentos processuais (pré) ...")
    # gerar alguns documentos processuais que serão referenciados
    doc_proc = gerar_documentos_processuais(n_doc_proc//2, autoridades, inst_jud, [])
    salvar_json("documentos_processuais_partial", doc_proc)

    print("Gerando denúncias...")
    denuncias = gerar_denuncias(n_denuncias)
    salvar_json("denuncias", denuncias)

    print("Gerando perfis digitais...")
    perfis = gerar_perfis_digitais(n_perfis, ocorrencias_oids=[])
    salvar_json("perfis_digitais", perfis)

    print("Gerando ocorrências (usando ids já gerados)...")
    ocorrencias = gerar_ocorrencias(n_ocorrencias, denuncias, inst_inv, agentes, perfis, inst_jud, doc_proc)
    salvar_json("ocorrencias", ocorrencias)

    print("Agora atualizando alguns documentos processuais com ocorrencias...")
    # gerar/atualizar documentos processuais finais vinculando ocorrencias
    more_doc_proc = gerar_documentos_processuais(n_doc_proc//2, autoridades, inst_jud, ocorrencias)
    all_doc_proc = doc_proc + more_doc_proc
    salvar_json("documentos_processuais", all_doc_proc)

    print("Finalizando: atualizando perfis/denuncias links (opcionais)...")
    # opcional: vincular algumas denuncias a ocorrencias
    for i, d in enumerate(denuncias[:len(ocorrencias)]):
        d["ocorrencia_id"] = ext_oid(ocorrencias[i]["_id"]["$oid"])
    salvar_json("denuncias_linked", denuncias)

    # opcional: atualizar perfis para apontar para ocorrencias aleatórias
    for p in perfis:
        # 30% chance de ter ocorrencia vinculada
        if random.random() < 0.3:
            p["ocorrencias"].append(ext_oid(random.choice(ocorrencias)["_id"]["$oid"]))
    salvar_json("perfis_digitais_linked", perfis)

    print("Concluído. Arquivos gerados no diretório atual.")

if __name__ == "__main__":
    main()
