from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from bson import ObjectId
from datetime import datetime
import pandas as pd
import json
import streamlit as st

# ============================
# 1. FUNÇÕES DE PARSE E NORMALIZAÇÃO
# ============================

def parse_oid(value):
    """Converte OID puro, dict OID ou None para string."""
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, dict) and "$oid" in value:
        return value["$oid"]
    if value is None:
        return None
    return str(value)


def parse_ext_date(value):
    """Converte datas de MongoDB para datetime."""
    if isinstance(value, datetime):
        return value
    if isinstance(value, dict) and "$date" in value:
        try:
            return pd.to_datetime(value["$date"])
        except:
            return None
    try:
        return pd.to_datetime(value)
    except:
        return None


def parse_oid_list(value):
    """Converte listas de ObjectId / Extended JSON para lista de strings."""
    if not isinstance(value, list):
        return []

    out = []
    for item in value:
        out.append(parse_oid(item))

    return out


def normalize_nested(value):
    """
    Normaliza QUALQUER valor que o PyArrow não consiga converter.
    - dicts → JSON string
    - listas → JSON string
    - datetime → string
    - ObjectId → string
    """

    # Datetime → string
    if isinstance(value, datetime) or hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except:
            pass

    # ObjectId → string
    if isinstance(value, ObjectId):
        return str(value)

    # dict → JSON string seguro
    if isinstance(value, dict):
        clean_dict = {k: normalize_nested(v) for k, v in value.items()}
        return json.dumps(clean_dict, ensure_ascii=False)

    # lista → JSON string seguro
    if isinstance(value, list):
        clean_list = [normalize_nested(v) for v in value]
        return json.dumps(clean_list, ensure_ascii=False)

    return value


def normalizar_dataframe(df):
    """Aplica normalização de datas, OIDs e listas padronizadas."""

    for col in df.columns:

        if col in ["data", "data_coleta", "created_at", "updated_at"]:
            df[col] = df[col].apply(parse_ext_date)
            continue

        if col.endswith("_id") and col != "_id":
            df[col] = df[col].apply(parse_oid)
            continue

        if col in ["agentes_responsaveis", "contas_digitais", "ocorrencias"]:
            df[col] = df[col].apply(parse_oid_list)
            continue

        if col == "_id":
            df[col] = df[col].apply(parse_oid)

    return df


# ==========================================================
# 2. CONEXÃO COM O MONGODB
# ==========================================================

uri = "mongodb+srv://teste:123@cluster0.l8o0uqo.mongodb.net/?appName=Cluster0"
client = MongoClient(uri, server_api=ServerApi("1"))

try:
    client.admin.command("ping")
    print("Conectado com sucesso!")
except Exception as e:
    print("Erro:", e)

db = client["sipacc_final"]


# ==========================================================
# 3. GERAÇÃO DOS DATAFRAMES COM NORMALIZAÇÃO COMPLETA
# ==========================================================

for nome_col in db.list_collection_names():

    print(f"\nProcessando coleção: {nome_col}")

    docs = list(db[nome_col].find())
    df = pd.DataFrame(docs)

    if df.empty:
        print(" → Coleção vazia")
        globals()[f"df_{nome_col}"] = df
        continue

    # Normalização padrão (datas, OIDs, listas de refs)
    df = normalizar_dataframe(df)

    # Normalização absoluta (remove TODOS os problemas do Streamlit)
    df = df.applymap(normalize_nested)

    # Salvar variável dinâmica
    var_name = f"df_{nome_col}"
    globals()[var_name] = df

    print(f" → Variável criada: {var_name} ({df.shape[0]} registros)")


print("\n=======================================")
print(" DATAFRAMES CRIADOS E NORMALIZADOS")
print(" PRONTOS PARA VISUALIZAÇÃO NO STREAMLIT")
print("=======================================\n")

# Exibir resumo
for nome_col in db.list_collection_names():
    var_name = f"df_{nome_col}"
    df = globals()[var_name]
    print(f"{var_name}: {df.shape[0]} linhas | {df.shape[1]} colunas")


# Painel desenvolvido em streamlit 
# -----------------------------------------
# SIPACC - Dashboard Streamlit
# -----------------------------------------
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from datetime import datetime
from PIL import Image

# -----------------------------------------
# CONFIGURAÇÕES DA PÁGINA
# -----------------------------------------
import streamlit as st

st.set_page_config(
    page_title="SIPACC - PAINEL",
    page_icon=Image.open("img/logo.jpg"),
    layout="wide"
)


# Conversões
df_ocorrencias["data"] = pd.to_datetime(df_ocorrencias["data"], errors="coerce")

# -----------------------------------------
# HEADER (LOGO / TÍTULO / ATUALIZAÇÃO)
# -----------------------------------------
logo, titulo, atualizacao = st.columns([1.5, 5, 2.5])

with logo:
    st.image("img/logo2-removebg-preview.png")  # coloque aqui sua logo se quiser

with titulo:
    st.title("SIPACC – Sistema de Investigação e Análise Cibernética")

with atualizacao:
    if len(df_ocorrencias) > 0:
        ultima_data = df_ocorrencias["data"].max().strftime("%d/%m/%Y")
        st.metric("Registro da última ocorrência", ultima_data)
    else:
        st.metric("Última atualização", "Sem dados")

# -----------------------------------------
# CARTÕES PRINCIPAIS
# -----------------------------------------
total_ocorrencias = len(df_ocorrencias)
total_agentes = len(df_agentes)
total_inst_jud = len(df_instituicoes_judiciais)
total_denuncias = len(df_denuncias)
crime_mais_frequente = df_ocorrencias["tipo_crime"].value_counts().idxmax()
crime_mais_frequente_count = df_denuncias["tipo_crime"].value_counts().max()

c1, c2, c3 = st.columns([3, 3, 3])

c1.metric("Total de Ocorrências Registradas", f"{total_ocorrencias}", border=True)
c2.metric(
    label="Crime Mais Recorrente",
    value=crime_mais_frequente,
    delta=f"{crime_mais_frequente_count} registros", border=True
)

c3.metric("Total de Denúncias", f"{total_denuncias}", border=True)

# -----------------------------------------
# VISUALIZAÇÃO 1: Série histórica de Ocorrências
# -----------------------------------------
st.subheader("📈 Série Histórica de Ocorrências Cibernéticas")

df_hist = (
    df_ocorrencias
    .groupby(df_ocorrencias["data"].dt.to_period("M"))
    .size()
    .reset_index(name="Total")
)
df_hist["data"] = df_hist["data"].astype(str)

fig_hist = px.line(
    df_hist,
    x="data",
    y="Total",
    markers=True,
    title="Ocorrências registradas por ano",
    labels={"data": "Ano", "Total": "Total de Ocorrências"}
)

st.plotly_chart(fig_hist, use_container_width=True)


import matplotlib.pyplot as plt
import seaborn as sns

# Criar tabela pivot Crime x Plataforma
crime_plat = df_denuncias.groupby(["tipo_crime", "plataforma"]).size().unstack().fillna(0)

# Gráfico
plt.figure(figsize=(8,4))
sns.heatmap(
    crime_plat,
    annot=False,
    cmap="Blues",
    linewidths=.5,
    linecolor="white",
    cbar_kws={"label": "Quantidade de denúncias"}
)
plt.title("Correlação Crime × Plataforma", fontsize=8)
plt.xlabel("Plataforma")
plt.ylabel("Tipo de Crime")

st.subheader("Correlação entre Tipo de Crime e Plataforma")

st.markdown("Esta matriz mostra a distribuição dos tipos de crimes por plataforma digital, permitindo identificar concentrações relevantes.")

# Inserir o gráfico
x, matriz, y = st.columns([1, 3, 1])
with matriz: 
    st.pyplot(plt.gcf())

import re
import pandas as pd
import numpy as np
import plotly.express as px
import streamlit as st

# Função robusta para extrair idade de um único elemento (string/dict-like)
def extract_age_from_text(x):
    """
    Tenta extrair a idade de um texto que pode ser:
     - uma string contendo '"idade": 30' (com ou sem vírgulas)
     - uma string com 'idade 30'
     - uma string com 'idade":30' etc.
     - se não achar, tenta pegar o primeiro número plausível (0-120)
    Retorna int ou None.
    """
    if x is None:
        return None

    # Se já for número
    if isinstance(x, (int, np.integer)):
        if 0 <= int(x) <= 120:
            return int(x)
        return None

    # Se for lista, processa o primeiro item (chamadora fará explode)
    if isinstance(x, list):
        # procurar em todos os elementos da lista e retornar o primeiro válido
        for el in x:
            age = extract_age_from_text(el)
            if age is not None:
                return age
        return None

    s = str(x)

    # padroniza aspas e espaços
    s = s.replace("'", '"')

    # 1) procurar padrões explícitos: "idade": 30  OR "idade" : "30" OR idade:30 OR idade 30
    patterns = [
        r'"\s*idade\s*"\s*[:=]\s*"?(\d{1,3})"?',   # "idade": "30" ou "idade":30
        r'\bidade\s*[:=]\s*"?(\d{1,3})"?',         # idade:30 ou idade=30
        r'\bidade\s+(\d{1,3})\b',                 # idade 30
        r'"idade"\s*[:=]\s*(\d{1,3})',            # variação sem aspas no número
        r'\\?\"idade\\?\"\s*[:=]\s*"?(\d{1,3})"?'  # casos com escapes
    ]
    for pat in patterns:
        m = re.search(pat, s, flags=re.IGNORECASE)
        if m:
            try:
                v = int(m.group(1))
                if 0 <= v <= 120:
                    return v
            except:
                pass

    # 2) fallback: pegar todos os números no texto e escolher o que parecer idade plausível
    nums = re.findall(r'\b(\d{1,3})\b', s)
    if nums:
        # converter para ints e filtrar plausíveis
        nums_int = [int(n) for n in nums if 0 <= int(n) <= 120]
        if nums_int:
            # heurística: preferir números entre 10 e 90; escolher o primeiro
            for cand in nums_int:
                if 5 <= cand <= 100:
                    return cand
            # senão, retornar o primeiro plausível encontrado
            return nums_int[0]
    return None

# --- Aplicação ao dataframe df_ocorrencias ---
# Cria série com as listas originais de vítimas (pode ser lista/string)
col = "vitimas"
if col not in df_ocorrencias.columns:
    st.warning(f"Coluna '{col}' não encontrada em df_ocorrencias.")
else:
    # Explodir para ter uma linha por vítima (cada célula pode ser string/list)
    exploded = df_ocorrencias[col].explode().dropna()

    # Extrair idade de cada item (cada item pode ser string, lista, dict)
    ages = exploded.apply(extract_age_from_text)

    # Remover valores nulos e converter para inteiro
    ages = ages.dropna().astype(int)

    # Se não houver idades encontradas
    if ages.empty:
        st.info("Nenhuma idade foi reconhecida nas entradas de 'vitimas'.")
    else:
        # Criar bins/faixas etárias (ajuste as faixas conforme desejar)
        bins = [17, 24, 34, 44, 54, 64, 120]
        labels = ["18-24","25-34","35-44","45-54","55-64","65+"]

        ages_binned = pd.cut(ages, bins=bins, labels=labels, right=True, include_lowest=True)
        counts = ages_binned.value_counts().reindex(labels).fillna(0).astype(int)

        # DataFrame para plot
        df_plot = counts.reset_index()
        df_plot.columns = ["faixa_etaria","qtd"]

        st.subheader("Ocorrências por Faixa Etária das Vítimas")

        # Gráfico interativo com Plotly
        fig = px.bar(
            df_plot,
            x="faixa_etaria",
            y="qtd",
            text="qtd",
            labels={"faixa_etaria":"Faixa Etária", "qtd":"Quantidade"},
            template="plotly_white"
        )
        fig.update_traces(textposition="outside")
        #fig.update_layout(yaxis=dict(dtick=1))
        st.plotly_chart(fig, use_container_width=True)

        


# Contagem de ocorrências por cidade
df_cidades = (
    df_ocorrencias.groupby("localizacao")
    .size()
    .reset_index(name="qtd_ocorrencias")
)

from geopy.geocoders import Nominatim
import time

geolocator = Nominatim(user_agent="sipacc-maps")

def geocode_city(city):
    try:
        location = geolocator.geocode(city + ", Brasil")
        if location:
            return pd.Series([location.latitude, location.longitude])
    except:
        pass
    return pd.Series([None, None])


# Criar colunas de latitude e longitude
df_cidades[["lat", "lon"]] = df_cidades["localizacao"].apply(geocode_city)

# Remover cidades sem coordenadas (caso existam)
df_cidades = df_cidades.dropna(subset=["lat", "lon"])

st.subheader("🗺️ Mapa das Cidades com Maior Número de Ocorrências")

st.map(df_cidades.rename(columns={"lat":"latitude","lon":"longitude"}))


# -----------------------------------------
# Rodapé
# -----------------------------------------
st.markdown("---")
st.write("Painel desenvolvido para o projeto SIPACC – Banco de Dados NoSQL • MongoDB + Streamlit")
